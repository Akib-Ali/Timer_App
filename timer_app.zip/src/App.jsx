import { useState } from 'react'
import './App.css'
import { Timer_Main_Task_Section_Main } from './Timer_Section/timer_show'



function App() {

  return (
    <div className="App">
  

      
      <Timer_Main_Task_Section_Main/>
    </div>
  )
}

export default App
